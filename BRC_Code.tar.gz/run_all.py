"""
在IDE中直接运行此文件即可训练全部4个数据集。
checkpoint保存在 checkpoints/ 目录下。
"""

import sys
import os

sys.argv = ["train.py"]  # reset argv
os.chdir(os.path.dirname(os.path.abspath(__file__)))

from train import main, DATASETS, prepare_data, train_one_epoch, evaluate, BRC
import torch
import torch.optim as optim
import numpy as np
import json
import time
from datetime import datetime

# ---- 配置 ----
CONFIG = {
    "epochs": 200,
    "lr": 1e-3,
    "batch_size": 64,
    "d_model": 128,
    "n_heads": 4,
    "K": 4,
    "d_ff": 512,
    "T_max": 3,
    "tau_base": 0.1,
    "r": 0.5,
    "lambda_kl": 1e-3,
    "lambda_cas": 1.0,
    "patience": 30,
    "seed": 42,
    "n_trials": 5,
}

SAVE_DIR = "checkpoints"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# ---- 要跑的数据集，按需注释 ----
RUN_DATASETS = [
    "california",   # California Housing
]


def run_one_dataset(dataset_name):
    os.makedirs(SAVE_DIR, exist_ok=True)
    cfg = CONFIG
    all_trial_metrics = []

    for trial in range(cfg["n_trials"]):
        seed = cfg["seed"] + trial
        torch.manual_seed(seed)
        np.random.seed(seed)

        train_loader, test_loader, data_info = prepare_data(
            dataset_name, batch_size=cfg["batch_size"], seed=seed
        )

        model = BRC(
            input_dim=data_info["input_dim"],
            d_model=cfg["d_model"], n_heads=cfg["n_heads"],
            K=cfg["K"], d_ff=cfg["d_ff"], T_max=cfg["T_max"],
            tau_base=cfg["tau_base"], r=cfg["r"], dropout=0.1,
        ).to(DEVICE)

        optimizer = optim.Adam(model.parameters(), lr=cfg["lr"], weight_decay=1e-5)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=10, factor=0.5)

        best_loss, best_state, wait = float("inf"), None, 0
        n_params = sum(p.numel() for p in model.parameters())

        print(f"\n{'='*60}")
        print(f"[{dataset_name}] Trial {trial+1}/{cfg['n_trials']}  |  {data_info['name']}  |  {n_params:,} params")
        print(f"{'='*60}")

        for epoch in range(1, cfg["epochs"] + 1):
            t0 = time.time()
            train_loss = train_one_epoch(
                model, train_loader, optimizer, DEVICE, cfg["lambda_kl"], cfg["lambda_cas"]
            )
            dt = time.time() - t0

            if epoch % 10 == 0 or epoch == 1:
                vm = evaluate(model, test_loader, DEVICE)
                scheduler.step(train_loss)
                print(f"  {epoch:3d} | loss {train_loss:.4f} | "
                      f"R2 {vm['R2']:.4f} | ECE {vm['ECE']:.4f} | PICP {vm['PICP']:.3f} | {dt:.1f}s")

            if train_loss < best_loss:
                best_loss = train_loss
                best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
                wait = 0
            else:
                wait += 1
                if wait >= cfg["patience"]:
                    print(f"  early stop @ epoch {epoch}")
                    break

        if best_state:
            model.load_state_dict(best_state)
            model.to(DEVICE)

        fm = evaluate(model, test_loader, DEVICE)
        all_trial_metrics.append(fm)
        print(f"\n  Final | R2 {fm['R2']:.4f} | RMSE {fm['RMSE']:.4f} | "
              f"PICP {fm['PICP']:.3f} | PINAW {fm['PINAW']:.4f} | ECE {fm['ECE']:.4f} | CRPS {fm['CRPS']:.4f}")

        torch.save({
            "model_state": model.state_dict(),
            "config": cfg,
            "data_info": data_info,
            "metrics": fm,
        }, os.path.join(SAVE_DIR, f"brc_{dataset_name}_trial{trial}.pt"))

    if cfg["n_trials"] > 1:
        print(f"\n{'='*60}\n[{dataset_name}] Aggregated ({cfg['n_trials']} trials):")
        for key in all_trial_metrics[0]:
            vals = [m[key] for m in all_trial_metrics]
            print(f"  {key:8s}: {np.mean(vals):.4f} +/- {np.std(vals):.4f}")

    with open(os.path.join(SAVE_DIR, f"brc_{dataset_name}_summary.json"), "w") as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "config": cfg,
            "data_info": data_info,
            "trials": all_trial_metrics,
        }, f, indent=2, default=float)


if __name__ == "__main__":
    print(f"Device: {DEVICE}")
    print(f"Datasets: {RUN_DATASETS}")
    print(f"Trials per dataset: {CONFIG['n_trials']}")
    print()

    for ds in RUN_DATASETS:
        run_one_dataset(ds)

    print("\n\nAll done. Checkpoints saved in checkpoints/")
