"""
BRC training script.

Wencan Guan <wencan.guan@uni-weimar.de>
"""

import argparse
import json
import os
import time
from datetime import datetime

import numpy as np
import torch
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from brc import BRC
from brc.metrics import (
    compute_r2, compute_picp, compute_pinaw,
    compute_ece_quantile, compute_crps, compute_ause,
)


# ---- dataset loaders ----

def load_energy_efficiency(target_col: int = 0):
    from sklearn.datasets import fetch_openml
    data = fetch_openml(data_id=242, as_frame=True, parser="auto")
    X = data.data.values.astype(np.float64)
    y = data.target
    if hasattr(y, "values"):
        y = y.values
    if y.ndim == 2:
        y = y[:, target_col]
    return X.astype(np.float32), y.astype(np.float32), "Energy Efficiency"


def load_california_housing():
    from sklearn.datasets import fetch_california_housing
    data = fetch_california_housing()
    return data.data.astype(np.float32), data.target.astype(np.float32), "California Housing"


def load_power_plant():
    from sklearn.datasets import fetch_openml
    data = fetch_openml(data_id=308, as_frame=True, parser="auto")
    return data.data.values.astype(np.float32), data.target.values.astype(np.float32), "Power Plant"


def load_student_performance():
    from sklearn.datasets import fetch_openml
    data = fetch_openml(data_id=574, as_frame=True, parser="auto")
    X = data.data.select_dtypes(include=[np.number]).values.astype(np.float32)
    return X, data.target.values.astype(np.float32), "Student Performance"


DATASETS = {
    "energy": load_energy_efficiency,
    "california": load_california_housing,
    "power": load_power_plant,
    "student": load_student_performance,
}


def prepare_data(name, test_size=0.2, batch_size=64, seed=42):
    X, y, display_name = DATASETS[name]()

    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=test_size, random_state=seed)

    sc_X = StandardScaler().fit(X_tr)
    sc_y = StandardScaler().fit(y_tr.reshape(-1, 1))

    X_tr = sc_X.transform(X_tr).astype(np.float32)
    X_te = sc_X.transform(X_te).astype(np.float32)
    y_tr = sc_y.transform(y_tr.reshape(-1, 1)).flatten().astype(np.float32)
    y_te = sc_y.transform(y_te.reshape(-1, 1)).flatten().astype(np.float32)

    train_loader = DataLoader(
        TensorDataset(torch.from_numpy(X_tr), torch.from_numpy(y_tr)),
        batch_size=batch_size, shuffle=True,
    )
    test_loader = DataLoader(
        TensorDataset(torch.from_numpy(X_te), torch.from_numpy(y_te)),
        batch_size=batch_size, shuffle=False,
    )

    info = {
        "name": display_name,
        "input_dim": X_tr.shape[1],
        "n_train": len(X_tr),
        "n_test": len(X_te),
        "y_range": float(y_te.max() - y_te.min()),
        "scaler_y_mean": float(sc_y.mean_[0]),
        "scaler_y_scale": float(sc_y.scale_[0]),
    }
    return train_loader, test_loader, info


# ---- training / eval ----

def train_one_epoch(model, loader, optimizer, device, lambda_kl, lambda_cas):
    model.train()
    total, n = 0.0, 0
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        loss, _ = model.compute_loss(xb, yb, lambda_kl=lambda_kl, lambda_cas=lambda_cas)
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        total += loss.item() * xb.shape[0]
        n += xb.shape[0]
    return total / n


@torch.no_grad()
def evaluate(model, loader, device, confidence=0.95):
    model.eval()
    mus, sigmas, ys = [], [], []
    for xb, yb in loader:
        out = model(xb.to(device))
        mus.append(out["mu"].cpu().numpy())
        sigmas.append(out["sigma2_total"].clamp(min=1e-8).sqrt().cpu().numpy())
        ys.append(yb.numpy())

    mu = np.concatenate(mus)
    sigma = np.concatenate(sigmas)
    y = np.concatenate(ys)

    from scipy.stats import norm
    z = norm.ppf(0.5 + confidence / 2.0)
    lo, hi = mu - z * sigma, mu + z * sigma

    return {
        "R2": compute_r2(y, mu),
        "RMSE": float(np.sqrt(np.mean((y - mu) ** 2))),
        "PICP": compute_picp(y, lo, hi),
        "PINAW": compute_pinaw(lo, hi, y_true=y),
        "ECE": compute_ece_quantile(y, mu, sigma),
        "CRPS": compute_crps(y, mu, sigma),
        "AUSE": compute_ause(y, mu, sigma),
    }


# ---- main ----

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", default="energy", choices=list(DATASETS.keys()))
    p.add_argument("--epochs", type=int, default=200)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--batch_size", type=int, default=64)
    p.add_argument("--d_model", type=int, default=128)
    p.add_argument("--n_heads", type=int, default=4)
    p.add_argument("--K", type=int, default=4)
    p.add_argument("--d_ff", type=int, default=512)
    p.add_argument("--T_max", type=int, default=3)
    p.add_argument("--tau_base", type=float, default=0.1)
    p.add_argument("--r", type=float, default=0.5)
    p.add_argument("--lambda_kl", type=float, default=1e-3)
    p.add_argument("--lambda_cas", type=float, default=1.0)
    p.add_argument("--patience", type=int, default=30)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--n_trials", type=int, default=1)
    p.add_argument("--save_dir", default="results")
    p.add_argument("--device", default="auto")
    args = p.parse_args()

    device = ("cuda" if torch.cuda.is_available() else "cpu") if args.device == "auto" else args.device
    os.makedirs(args.save_dir, exist_ok=True)
    all_trial_metrics = []

    for trial in range(args.n_trials):
        seed = args.seed + trial
        torch.manual_seed(seed)
        np.random.seed(seed)

        train_loader, test_loader, data_info = prepare_data(
            args.dataset, batch_size=args.batch_size, seed=seed
        )

        model = BRC(
            input_dim=data_info["input_dim"],
            d_model=args.d_model, n_heads=args.n_heads,
            K=args.K, d_ff=args.d_ff, T_max=args.T_max,
            tau_base=args.tau_base, r=args.r, dropout=0.1,
        ).to(device)

        optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-5)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=10, factor=0.5)

        best_loss, best_state, wait = float("inf"), None, 0
        n_params = sum(p.numel() for p in model.parameters())

        print(f"\n{'='*60}")
        print(f"Trial {trial+1}/{args.n_trials}  |  {data_info['name']}  |  {n_params:,} params")
        print(f"{'='*60}")

        for epoch in range(1, args.epochs + 1):
            t0 = time.time()
            train_loss = train_one_epoch(
                model, train_loader, optimizer, device, args.lambda_kl, args.lambda_cas
            )
            dt = time.time() - t0

            if epoch % 10 == 0 or epoch == 1:
                vm = evaluate(model, test_loader, device)
                scheduler.step(train_loss)
                print(f"  {epoch:3d} | loss {train_loss:.4f} | "
                      f"R2 {vm['R2']:.4f} | ECE {vm['ECE']:.4f} | PICP {vm['PICP']:.3f} | {dt:.1f}s")

            if train_loss < best_loss:
                best_loss = train_loss
                best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
                wait = 0
            else:
                wait += 1
                if wait >= args.patience:
                    print(f"  early stop @ epoch {epoch}")
                    break

        if best_state:
            model.load_state_dict(best_state)
            model.to(device)

        fm = evaluate(model, test_loader, device)
        all_trial_metrics.append(fm)
        print(f"\n  Final | R2 {fm['R2']:.4f} | RMSE {fm['RMSE']:.4f} | "
              f"PICP {fm['PICP']:.3f} | PINAW {fm['PINAW']:.4f} | ECE {fm['ECE']:.4f} | CRPS {fm['CRPS']:.4f}")

        torch.save({
            "model_state": model.state_dict(),
            "config": vars(args),
            "data_info": data_info,
            "metrics": fm,
        }, os.path.join(args.save_dir, f"brc_{args.dataset}_trial{trial}.pt"))

    if args.n_trials > 1:
        print(f"\n{'='*60}\nAggregated ({args.n_trials} trials):")
        for key in all_trial_metrics[0]:
            vals = [m[key] for m in all_trial_metrics]
            print(f"  {key:8s}: {np.mean(vals):.4f} +/- {np.std(vals):.4f}")

    summary_path = os.path.join(args.save_dir, f"brc_{args.dataset}_summary.json")
    with open(summary_path, "w") as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "config": vars(args),
            "data_info": data_info,
            "trials": all_trial_metrics,
        }, f, indent=2, default=float)
    print(f"\nSaved to {summary_path}")


if __name__ == "__main__":
    main()
